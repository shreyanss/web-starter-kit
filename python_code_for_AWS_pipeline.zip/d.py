#from bson import json_util
#from datetime import datetime
#from operator import attrgetter
import os
import requests
import json
import yaml
import boto3
client = boto3.client('ecr', region_name='us-east-2')
code_pipeline = boto3.client('codepipeline')

def put_job_success(job, message):
    """Notify CodePipeline of a successful job
    
    Args:
        job: The CodePipeline job ID
        message: A message to be logged relating to the job status
        
    Raises:
        Exception: Any exception thrown by .put_job_success_result()
    
    """
    print('Putting job success')
    print(message)
    code_pipeline.put_job_success_result(jobId=job)
    
def put_job_failure(job, message):
    """Notify CodePipeline of a failed job
    
    Args:
        job: The CodePipeline job ID
        message: A message to be logged relating to the job status
        
    Raises:
        Exception: Any exception thrown by .put_job_failure_result()
    
    """
    print('Putting job failure')
    print(message)
    code_pipeline.put_job_failure_result(jobId=job, failureDetails={'message': message, 'type': 'JobFailed'})



def handler(event, context):
 
 response = client.describe_images(repositoryName='python') #json response with list of images
 
 r=response['imageDetails']
 for each in r:
  print(each['imageTags'], end =" ")
  print(each['imagePushedAt'])
  
 print('******************sorted list************************')
 x= sorted(r, key = lambda i: i['imagePushedAt'],reverse=True)
 for a in x:
  print(a['imageTags'], end =" ")
  print(a['imagePushedAt'])
 print('**************')
 img=x[0]['imageTags'][0]
 print(img)
 print('**************')
 url='715146130151.dkr.ecr.us-east-2.amazonaws.com/python:'+img
 print(url)
 
 address = 'https://E25AD8FEA1054476029ACB83C5883114.yl4.us-east-2.eks.amazonaws.com/apis/apps/v1/namespaces/default/deployments/sa-logic'
 headers = {'content-type': 'application/strategic-merge-patch+json'}
 kubedata={"spec": {"template": {"spec": {"containers": [{"name": "sa-logic","image": url,"ports": [{"containerPort": 5000,"protocol": "TCP"}]}]}}}}
 print(kubedata)
 data_to_send = json.dumps(kubedata).encode("utf-8")
 
 try:
   # Extract the Job ID
  job_id = event['CodePipeline.job']['id']
  r = requests.patch(address,data=data_to_send,headers=headers,verify="/var/task/ca.crt") #verify="/var/task/ca.crt"
  put_job_success(job_id, 'Image Patched')
 except Exception as e:
  print(e)
  put_job_failure( job_id,'Function exception: ' + str(e))
  raise e
 
 print(r.text)
 return {'message' : 'patched'}  
 